<?php
/**
 * Created by PhpStorm.
 * User: sana
 * Date: 18.08.18
 * Time: 17:00
 */

namespace app\controllers;


use app\models\CornHybrids;
use app\models\Cultures;
use app\models\Hybrids;
use yii\rest\ActiveController;

class HybridsController extends ActiveController
{
    public $modelClass = 'app\models\Hybrids';

    public function actions()
    {
        $actions = parent::actions();

        $actions['index']['prepareDataProvider'] = [$this, 'prepareDataProvider'];
        return $actions;
    }

    public function prepareDataProvider()
    {
        if (\Yii::$app->request->get('outputType') === 'xml') {
            \Yii::$app->response->format = \yii\web\Response::FORMAT_XML;
        }

        $culturesID = \Yii::$app->request->get('culturesID');
        if ($culturesID && intval($culturesID) > 0) {
            return  Cultures::findOne(['id' => $culturesID])->hybrids;
        }

        $FAOUnits = \Yii::$app->request->get('FAOUnits');
        if ($FAOUnits) {
            $FAOArray = explode(',',$FAOUnits);
            $cornHybrids = CornHybrids::find()->where(['between', 'FAOUnits', $FAOArray[0], $FAOArray[1]])->asArray()->addSelect('HybridId')->all();
            return Hybrids::findAll(['id' => array_column($cornHybrids,'HybridId')]);
        }
        return Hybrids::find()->all();
    }
}